# -*- coding: utf-8 -*-

import math
import numpy as np
import cv2

Hw4_Image_Ori_Path = './toCalibrated.jpg'
Hw4_Image_PickUp_Path = './PickUp_Point.jpg'
HW4_K_Matrix = './K_Matrix.txt'
Ori_Imgae = cv2.imread(Hw4_Image_Ori_Path)

Shape_Coner = [[0.,0.],[0.,30.],[30.,30.],[30.,0.]] 
Coner_Left = [[213.,219.],[266.,460.],[385.,348.],[357.,145.]]
Coner_Right = [[459.,130.],[476.,326.],[673.,351.],[678.,137.]]
Coner_Bottom = [[455.,419.],[354.,544.],[595.,597.],[656.,448.]]


CorList = []
Coner_Left = [[213,219],[266,460],[385,348],[357,145]]
Coner_Right = [[459,130],[476,326],[673,351],[678,137]]
Coner_Bottom = [[455,419],[354,544],[595,597],[656,448]]
CorList.append(Coner_Left)
CorList.append(Coner_Right)
CorList.append(Coner_Bottom)


def show_circle_image(CorList, Ori_Imgae):
    ''' Show Pick Up Point Image '''

    radius = 2
    color = (0, 0, 255)   
    thickness = 2
    index = 0
    for CorPoint in CorList:
        for point in CorPoint:
            Circle_image = cv2.circle(Ori_Imgae, tuple(point), radius, color, thickness)
            cv2.putText(Circle_image, str(index), tuple(point), cv2.FONT_HERSHEY_SIMPLEX,1, color, 1, cv2.LINE_AA)
            index+=1

    cv2.imwrite(Hw4_Image_PickUp_Path,Circle_image)
    print("Save PickUp 12 Points into JPG File\n")

def cal_cv2_homography(x, xp):
    '''
    透過 OpenCV 計算 Homography 矩陣數值
    x' = H * X
    '''
    HomoMatrix, _ = cv2.findHomography(np.asarray(x), np.asarray(xp))
    return HomoMatrix

def cal_merge_matrix(hap, hbp, hcp):
    ''' Merge 3 Homography Matrix '''

    return np.asarray([
    [hap[0][0]*hap[1][0], (hap[0][0]*hap[1][1]+hap[0][1]*hap[1][0]), (hap[0][0]*hap[1][2]+hap[0][2]*hap[1][0]), hap[0][1]*hap[1][1], (hap[0][1]*hap[1][2]+hap[0][2]*hap[1][1]) , hap[0][2]*hap[1][2]],
    [(hap[0][0]**2 - hap[1][0]**2), 2*(hap[0][0]*hap[0][1]-hap[1][0]*hap[1][1]), 2*(hap[0][0]*hap[0][2]-hap[1][0]*hap[1][2]), (hap[0][1]**2 - hap[1][1]**2), 2*(hap[0][1]*hap[0][2]-hap[1][1]*hap[1][2]) , (hap[0][2]**2-hap[1][2]**2)],
    [hbp[0][0]*hbp[1][0], (hbp[0][0]*hbp[1][1]+hbp[0][1]*hbp[1][0]), (hbp[0][0]*hbp[1][2]+hbp[0][2]*hbp[1][0]), hbp[0][1]*hbp[1][1], (hbp[0][1]*hbp[1][2]+hbp[0][2]*hbp[1][1]) , hbp[0][2]*hbp[1][2]],
    [(hbp[0][0]**2 - hbp[1][0]**2), 2*(hbp[0][0]*hbp[0][1]-hbp[1][0]*hbp[1][1]), 2*(hbp[0][0]*hbp[0][2]-hbp[1][0]*hbp[1][2]), (hbp[0][1]**2 - hbp[1][1]**2), 2*(hbp[0][1]*hbp[0][2]-hbp[1][1]*hbp[1][2]) , (hbp[0][2]**2-hbp[1][2]**2)],
    [hcp[0][0]*hcp[1][0], (hcp[0][0]*hcp[1][1]+hcp[0][1]*hcp[1][0]), (hcp[0][0]*hcp[1][2]+hcp[0][2]*hcp[1][0]), hcp[0][1]*hcp[1][1], (hcp[0][1]*hcp[1][2]+hcp[0][2]*hcp[1][1]) , hcp[0][2]*hcp[1][2]],
    [(hcp[0][0]**2 - hcp[1][0]**2), 2*(hcp[0][0]*hcp[0][1]-hcp[1][0]*hcp[1][1]), 2*(hcp[0][0]*hcp[0][2]-hcp[1][0]*hcp[1][2]), (hcp[0][1]**2 - hcp[1][1]**2), 2*(hcp[0][1]*hcp[0][2]-hcp[1][1]*hcp[1][2]) , (hcp[0][2]**2-hcp[1][2]**2)],
    ])
    
def svd_matrix_v(MergeMatirx):
    ''' SVD solve v Matrux and Transefer '''
    _, _, v = np.linalg.svd(MergeMatirx)
    return v.T

def cal_w(v):
    '''
    Calculate W and arrange into matrix
    '''

    v = np.around(v, decimals=20)
    return np.asarray([
    [v[0][5],v[1][5],v[2][5]],
    [v[1][5],v[3][5],v[4][5]],
    [v[2][5],v[4][5],v[5][5]],               
    ])

def matrix_inverse_nomalize(w):
    '''
    Inverse Matrix and Nomalize
    '''
    inw = np.linalg.inv(w)*(10**6)
    normalizeByValue = inw[2][2]
    return inw / normalizeByValue

def get_k_matrix(inw):
    '''
    Calculate K Matrix and Write to File
    '''

    c = inw[0][2]
    e = inw[1][2]
    d = math.sqrt(abs(inw[1][1] - e**2))
    b = (inw[0][1] - c*e)/d
    a = math.sqrt(abs(inw[0][0]-b**2-c**2))
    c, e, d, b, a, inw[2][2]

    K = [
    [a,b,c],
    [0,d,e],     
    [0,0,inw[2][2]]
    ]

    WriteK_Matrix = open(HW4_K_Matrix, 'w')
    for row in K:
        WriteK_Matrix.writelines(str(list(row)))
        WriteK_Matrix.writelines('\n')
        print(row)
    WriteK_Matrix.close()
    
    print("Save K into K_Matrix.txt File\n")

def main():
    
    # 確認點位座標與順序, 並產生圖檔 PickUp_Point.jpg
    show_circle_image(CorList, Ori_Imgae)

    # 計算 3 個 Homography 與取得 Row1 & Row2
    ha, hb, hc = cal_cv2_homography(Shape_Coner,Coner_Left), cal_cv2_homography(Shape_Coner,Coner_Right), cal_cv2_homography(Shape_Coner,Coner_Bottom)
    hap, hbp, hcp = ha.T[0:2], hb.T[0:2], hc.T[0:2]

    # 合併矩陣
    merge_matrix = cal_merge_matrix(hap, hbp, hcp)
    
    # SVD 求得 V
    v = svd_matrix_v(merge_matrix)

    # 計算 W 矩陣
    w = cal_w(v)

    # Inverse 與 正規化
    inw = matrix_inverse_nomalize(w)

    # 計算 K 與存檔
    get_k_matrix(inw)



if __name__ == '__main__':
    main()
    